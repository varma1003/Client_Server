'''
This module contains all functionalities for the user.
'''

import os
import time
import pandas

class Service():
    '''
        methods in Service class:
        1) __init__(self)
        2) change_folder(self,fldr_id)
        3) register(self,id,pwd)
        4) create_folder(self,fldr_id)
        5) login(self, user_id, user_pwd)
        6) list(self)
        7) write_file(self, file_name, text_for_write = None)
        8) read_file(self, file_name = None)
        9) len_content_in_file(self,path)
       10) quit(self)
    '''

    def __init__(self):

        '''
            Intialisation of variables
        '''
        self.user_id = None
        self.file_index_number = {}
        self.users_in = None
        self.cur_users = None
        self.user_path = None
        self.is_loggedin = False

    def create_folder(self,fldr_id):

        '''
            This method is responsible for folder creation
            for a given folder name.
        '''

        if not self.is_loggedin:
            return "\nlogin is required to create folder"
        path = self.user_path

        folders_list = os.listdir(path)
        if fldr_id in folders_list:
            return "Folder cannot be created as it already exist"
        else:
            os.mkdir(os.path.join(path, fldr_id))
            return f"Folder name:{fldr_id} is created in path >>{self.user_path}"

    def change_folder(self,fldr_id):
        '''
            This method is responsible to change directory forward or backward
            for a given path name
        '''
        try:
            if not self.is_loggedin:
                return "\nlogin is required to change folder"
            cur_dir = self.user_path
            list_of_folders=os.listdir(cur_dir)
            if fldr_id in list_of_folders:
                self.user_path +=f"/{fldr_id}"
                return f"directory changed to >> {self.user_path}"
            elif fldr_id == "folder":
                return "cannot create folder named folder"
            elif fldr_id == "..":
                if len(self.user_path.split("/")) > 2:
                    path_temp = self.user_path.split("/")[0:-1]

                    self.user_path = "/".join(path_temp)
                    return f"directory changed to >> {self.user_path}"
                else:
                    return "directory can't be changed back to root directory !!!!"
            else:
                return f"No folder with name:{fldr_id} is found"
        except OSError:
            return "OSError occured to change folder"

    def register(self,identity,pwd):

        '''
            This method is responsible for registration of new users
            for given user name and password
        '''
        try:
            if self.is_loggedin:
                return "\nLogout first to register new user"
            list_of_users = pandas.read_csv("Server_data/users.csv")
            list_of_usernms=list_of_users['username'].tolist()
            if identity in list_of_usernms:
                return "Username unavailable"

            new_details = pandas.DataFrame(columns=['username','password'])
            os.mkdir(os.path.join("Root/",str(identity)))

            new_details['username'] = [identity]
            new_details['password'] = pwd
            list_of_users = list_of_users.append(new_details)
            list_of_users.to_csv("Server_data/Users.csv",index = False)

            return "\nRegisteration completed  :)"
        except OSError:
            return "OSError occured while registring the user"

    def login(self, user_id, user_pwd):

        '''
            This method is responsible for user to login
            with given user credenials as name and password
        '''

        self.cur_users = pandas.read_csv("Server_data/current_users.csv")
        self.users_in = pandas.read_csv("Server_data/users.csv")

        sample_dict = {}

        if self.is_loggedin:
            return "\n User already logged in"
        else:
            user_login_list = []
            user_login_pwd = []

            cur_users = self.cur_users
            sample_dict = self.users_in.to_dict('split')

            i = 0
            while i<len(sample_dict['index']):
                user_login_list.append(sample_dict['data'][i][0])
                user_login_pwd.append(sample_dict['data'][i][1])
                i+=1

            if user_id not in user_login_list:
                return "\n-x-x-x-x-x-User not registered or wrong username-x-x-x-x-x"
            if user_pwd not in user_login_pwd:
                return "\n-x-x-x-password is wrong-x-x-x"
            if user_id in cur_users['username'].tolist():
                return "\nThis user is loggedin from other address"

            user_column = pandas.DataFrame(columns=['username'])
            self.user_id = user_id
            self.user_path = "Root/" + user_id
            user_column['username'] = [user_id]
            cur_users = cur_users.append(user_column)
            cur_users.to_csv('Server_data/current_users.csv',index = False)
            self.is_loggedin = True
            return "\n User login Done."

    def quit(self):
        '''
            This method is responsible to for logging out user and close application
        '''
        try:
            if not self.is_loggedin:
                return "login is required"
            else:
                user_details = pandas.read_csv('Server_data/current_users.csv')
                temp_user_details = user_details.to_dict('split')
                sample = {}

                for i in range(len(user_details)):
                    sample[temp_user_details['data'][i][0]] = temp_user_details['index'][i]

                new_user_details = user_details.drop(sample[self.user_id])
                new_user_details.to_csv('Server_data/current_users.csv',index = False)
                self.is_loggedin = False
                self.user_id = ""
                return "-x-x-x-x-x-Session ended by user-x-x-x-x-x "
        except OSError:
            print("Unable to logout, error occured")

    def list(self):

        '''
            This method is responsible to display list of files and
            thier details present in current directory
        '''
        if not self.is_loggedin:
            return "\nlogin is required"
        else:
            lst = []
            for lst_files in os.listdir(self.user_path):
                details_of_files = os.stat(os.path.join(self.user_path,lst_files))
                detailes_of_files_lst = list((lst_files, str(details_of_files.st_size),
                str(time.ctime(details_of_files.st_ctime))))
                lst.append(detailes_of_files_lst)

            information_of_files = ''
            information_of_files += f"\nThe current directory is >> {self.user_path}"
            information_of_files +="\nFile   ||   Size   ||   Date & Time   ||\n"
            for x in lst:
                data = " || ".join(x[0:]) + "\n"
                information_of_files += data
            return information_of_files

    def read_file(self, file_name = None):

        '''
            This method is responsible to display contents
            for a given file name.
        '''
        results = None
        if not self.is_loggedin:
            return "\nlogin is required"
        else:
            if file_name == None:
                self.file_index_number.clear()
                return "terminated opened reading files"
            else:
                path = f"{self.user_path}/{file_name}"
                if path not in self.file_index_number.keys():
                    if file_name in os.listdir(self.user_path):
                        with open(path, 'r') as read_obj:
                            read_input = read_obj.read(1)
                            if not read_input:
                                return "!!! Empty file !!!"
                        file_op = open(path,"r")
                        self.file_index_number[path] = 100
                        results = file_op.read(100).rstrip()
                else:
                    file_op = open(path, "r")
                    if os.stat(path).st_size == 0:
                        return "!!! Empty file !!!"
                    else:
                        open_file = open(path,"r")
                        len_of_file = len(open_file.read())
                        open_file.close()
                        if self.file_index_number[path] < len_of_file:
                            file_op.seek(self.file_index_number[path])
                        else:
                            results = file_op.read(100).rstrip()
                            self.file_index_number[path] +=100
                        if self.file_index_number[path] > len_of_file:
                            file_op.close()
                            del self.file_index_number[path]

                return results

    def write_file(self, file_name, text_for_write = None):

        '''
            This method is responsible to write given contents into a file,
            if parameters are empty then contents in that file are erased
        '''

        if not self.is_loggedin:
            return "\nlogin is required"
        else:
            if text_for_write == None:
                file_op = open(f"{self.user_path}/{file_name}","w")
                file_op.write("")
                file_op.close()
                return f"Removed contents in ->{file_name}"
            else:
                file_op = open(f"{self.user_path}/{file_name}","a")
                file_op.write(text_for_write)
                file_op.close()
                return f"updated contents in ->{file_name}"
