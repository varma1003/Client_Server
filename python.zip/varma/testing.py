'''
This module deals with testing of the 
client-server application
'''
import unittest
import shutil
import pandas
from server_operations import Service

real_users = pandas.read_csv('Server_data/users.csv')
real_current_users = pandas.read_csv('Server_data/current_users.csv')

class TestApp(unittest.TestCase):
    '''
        This class containes the test cases for commands in the application
    '''

    def test_register(self):
        """
            test for registration
        """

        usr_info = Service()
        self.assertEqual(usr_info.register("kumar","kumar1234"), 'Username unavailable')



    def test_write_file(self):
        """
            test for writing into a file
        """

        usr_info = Service()
        usr_info.register("virat", "virat18")
        usr_info.login("virat", "virat18")
        content = "Lorem ipsum dolor sit amet, viverra arcu.Donec ac tortor ut."
        file_name = "loremtxt"
        self.assertEqual(usr_info.write_file(file_name,content),f"\nlogin is required")


    def test_quit(self):
        """
            test for exiting application
        """

        usr_info = Service()
        usr_info.register("bobby", "passbebe")
        usr_info.login("bobby", "passbebe")
        self.assertEqual(usr_info.quit(), "login is required")



def test_sequence(tests):

    test_load = unittest.TestLoader()
    test_suite = unittest.TestSuite()

    test_suite.addTests(test_load.loadTestsFromTestCase(tests))
    test_run = unittest.TextTestRunner(verbosity=2)
    output = test_run.run(test_suite)

    if output.skipped:
        return False

    return output.wasSuccessful()

if __name__ == "__main__":
    print('-'*50 + "\nTesting:\n")
    if test_sequence(TestApp) is not True:
        print("\n\tThe tests did not pass,")
    
