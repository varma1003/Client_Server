'''
    This module is responsible from client
'''
import asyncio

async def client_app():
    '''
        This method is responsible for running client application.
    '''

    reader, writer = await asyncio.open_connection('127.0.0.1',8888)
    input_command = ''
    while True:
        input_command = input('Enter command:')
        if input_command == '':
            print("Invalid cmd\n")
            continue
        if input_command.rstrip("\n").rstrip(" ").lstrip(" ") == "commands":
            list_of_commands={"register":"register new user"
            "\ncmd:->register <username> <password>\n",
            "login":"login with provided username and password"
            "\ncmd:-> login <username> <password>\n",
            "list": "lists all files in current directory"
            "\ncmd:-> list\n",
            "read_file": "reads the file content from file"
            "\ncmd:-> read_file <name>"
            "\ncloses current opened file"
            "\ncmd:-> read_file\n",
            "write_file": "writes into the provided file"
            "\ncmd:-> write_file <name> <input>"
            "\nremoves all the content from the file."
            "\ncmd:-> write_file <name>\n",
            "change_folder":"change the directory to provided file name"
            "\ncmd:-> change_folder <name>"
            "\nChange back to previous directory"
            "\ncmd:-> change_folder ..\n",
            "create_folder":"create folder in current directory"
            "\ncmd:-> create_folder <name>"
            }
            for i in list_of_commands:
                print(f"{i} - {list_of_commands[i]}")
            continue

        writer.write(input_command.encode())

        data = await reader.read(1000)
        print(f'Received: {data.decode()}')
        if input_command.lower() == "quit":
            break
    print('Close the connection')
    writer.close()

asyncio.run(client_app())
