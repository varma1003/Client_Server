'''
    This module is responsible for running of server
'''
import os
import asyncio
import signal
import pandas
from server_operations import Service

#for ctrl+c to exit
signal.signal(signal.SIGINT, signal.SIG_DFL)

def client_service(usr_info, input_command):
    '''
        This method is responsible for calling commands in Service class.
    '''

    usr_info.users_in = pandas.read_csv("Server_data/users.csv")
    usr_info.cur_users = pandas.read_csv("Server_data/current_users.csv")

    input_command =  input_command.rstrip("\n").rstrip(" ").lstrip(" ")
    ip = input_command.split(" ")[0]
    len_cmd = len(input_command.split(" "))
    if ip == "register":
        if len_cmd == 3:
            return usr_info.register(input_command.split(" ")[1], input_command.split(" ")[2])
        else:
            return "Given wrong arguments"
    elif ip == "login":
        if len_cmd == 3:
            return usr_info.login(input_command.split(" ")[1], input_command.split(" ")[2])
        else:
            return "Given wrong arguments"
    elif ip == "list":
        return usr_info.list()
    elif ip == "create_folder":
        if len_cmd == 2:
            return usr_info.create_folder(input_command.split(" ")[1])
    elif ip == "change_folder":
        if len_cmd == 2:
            return usr_info.change_folder(input_command.split(" ")[1])
    elif ip == "write_file":
        if len_cmd >= 3:
            return usr_info.write_file(input_command.split(" ")[1]," ".join(input_command.split(" ")[2: ]))
        elif len_cmd == 2:
            return usr_info.write_file(input_command.split(" ")[1])
    elif ip == "read_file":
        if len_cmd == 2:
            return usr_info.read_file(input_command.split(" ")[1])
        if len_cmd == 1:
            return usr_info.read_file()
    elif ip == "quit":
        if len_cmd == 1:
            return usr_info.quit()
    else:
        return "Choose correct command, enter commands for dispaly of available commands"


async def command_result(reader, writer):
    '''
        
    '''
    connection_number = writer.get_extra_info('peername')
    response = f'{connection_number} is connected !!!!'
    print(response)

    usr_info = Service()

    while True:
        read_ip = await reader.read(1000)
        response = read_ip.decode().strip()

        print(f"Received {response} from {connection_number}")
        feedback = client_service(usr_info, response)

        writer.write(str(feedback).encode())
        await writer.drain()
        if response == 'quit':
            break

    print("Close the connection")
    writer.close()

async def main():
    '''
        This function establish the connection
        between client and server
    '''

    info_of_user = pandas.DataFrame(columns=['username'])
    cur_work_directory=os.getcwd()
    path=cur_work_directory+"\Server_data\cur_users.csv"
    info_of_user.to_csv(path,index=False)

    server = await asyncio.start_server(
        command_result, '127.0.0.1', 8888
    )

    server_addr = server.sockets[0].getsockname()
    print(f'Serving on {server_addr}')

    async with server:
        await server.serve_forever()

asyncio.run(main())
